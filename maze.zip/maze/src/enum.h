#ifndef ENUM_H
#define ENUM_H
enum junction
{
    LS,
    LR,
    R,
    L,
    SR,
    LSR,
    E,
    STOP
};
enum desition
{
    LT,
    RT,
    FW,
    BW,
    END,
    START
};
enum ruletype
{
    LEFT,
    RIGHT
};
#endif
